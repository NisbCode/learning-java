package br.com.abc.javacore.Minterfaces.classes;

public interface Transportavel {
    public void calculaFrete();
}
