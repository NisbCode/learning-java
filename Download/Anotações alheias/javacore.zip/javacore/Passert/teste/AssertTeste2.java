package br.com.abc.javacore.Passert.teste;

public class AssertTeste2 {
    public static void main(String[] args) {
        Assert testeAssert = new Assert();

        testeAssert.calculaSalario();
    }
}
