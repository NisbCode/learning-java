package br.com.abc.javacore.ZZMcompletablefuture.teste;

/**
 * REQUISIÇÕES ASSÍNCRONAS,
 * para o caso do desenvolvedor não poder
 * mudar as classes da API usada
 */
public class LojaTeste2 {
    public static void main(String[] args) {
            
    }
}
