package br.com.abc.javacore.Oexception.checkedexceptions.classes;

import br.com.abc.javacore.Oexception.customexception.classes.LoginInvalidoException;

import java.io.FileNotFoundException;

public class Pessoa {
    public void salvar() throws LoginInvalidoException, FileNotFoundException{

    }
}
