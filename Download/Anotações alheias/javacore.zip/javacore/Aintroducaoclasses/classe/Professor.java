package br.com.abc.javacore.Aintroducaoclasses.classe;

/***
 * EXERCICIO
 * CRIE OS SEGUINTES ATRIBUTOS PRA ESSA CLASSE:
 * Nome
 * Matricula
 * Rg
 * cpf
 *
 * EM SEGUIDA, CRIE UMA CLASSE DE TESTE PARA
 * PREENCHER E IMPRIMIR OS DADOS
 */

public class Professor {

    public String nome;
//  Certas instituições adicionam também letras
//  à matricula, sendo assim necessário utilizar
//  String, ao inves de int
//  SÓ SE DEVE USAR INT SE TIVER A CERTEZA DE QUE
//  SÓ NUMEROS SERÃO UTILIZADOS
    public String matricula;
    public int rg;
    public long cpf;
}
