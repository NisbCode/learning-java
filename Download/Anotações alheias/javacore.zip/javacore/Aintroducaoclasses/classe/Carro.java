package br.com.abc.javacore.Aintroducaoclasses.classe;

public class Carro {
    public String placa;
    public String modelo;
    public float velocidadeMaxima;
}
