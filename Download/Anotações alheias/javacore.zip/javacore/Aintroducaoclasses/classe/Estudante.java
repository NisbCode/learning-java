package br.com.abc.javacore.Aintroducaoclasses.classe;

public class Estudante {

    /***
     * ORIENTAÇÃO A OBJETOS:
     *
     * Atributos = variáveis de instância
     * Comportamnetos (ações) = métodos
     */

    public String nome;
    public String matricula;
    public int idade;

}
