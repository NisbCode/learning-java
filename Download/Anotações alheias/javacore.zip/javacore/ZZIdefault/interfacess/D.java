package br.com.abc.javacore.ZZIdefault.interfacess;

import br.com.abc.javacore.ZZIdefault.interfacess.InterfaceA;

public class D implements InterfaceA {
    public void relevanciaClasseOuInterface(){
        System.out.println("Classe é mais relevante");
    }
}
