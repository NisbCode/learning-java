package br.com.abc.javacore.ZZIdefault.interfacess;

public interface InterfaceE {
    default void mesmoMetodo(){
        System.out.println("É o mesmo metodo, mermao");
    }
}
