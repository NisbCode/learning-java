package br.com.abc.javacore.ZZKstreams.classes;

public enum Maioridade {
    MENOR, ADULTO;
}
