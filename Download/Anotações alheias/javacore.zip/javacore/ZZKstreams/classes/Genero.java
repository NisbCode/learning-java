package br.com.abc.javacore.ZZKstreams.classes;

public enum Genero {
    MASCULINO, FEMININO;
}
