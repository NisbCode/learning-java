package br.com.abc.javacore.Dsobrecargaconstrutores.teste;

import br.com.abc.javacore.Dsobrecargaconstrutores.classes.Estudante;

public class EstudanteTeste {
    public static void main(String[] args) {
        Estudante jisoo = new Estudante("1515151", "Jisoo", new double[]{10,9,8});

       jisoo.imprime();

    }





}
