package br.com.abc.javacore.ZZFpadroesdeprojeto.classes;

public enum Pais {
    BRASIL, EUA;
}
