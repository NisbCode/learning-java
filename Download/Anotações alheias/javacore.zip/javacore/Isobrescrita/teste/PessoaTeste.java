package br.com.abc.javacore.Isobrescrita.teste;

import br.com.abc.javacore.Isobrescrita.classes.Pessoa;

public class PessoaTeste {
    public static void main(String[] args) {
        Pessoa p = new Pessoa();
        p.setNome("Goku");
        p.setIdade(45);

        System.out.println(p);

    }
}
